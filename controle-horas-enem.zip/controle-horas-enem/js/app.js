const DISC=["Matemática","Física","Química","Biologia","História","Geografia","Filosofia","Sociologia","Português","Literatura","Inglês","Redação"];
const DIAS=["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"],MES=["jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez"];
const DG=[6.5,3,3,3.5,2.5,2.5,1.5,1.5,3,2,2.5,4.5];
const COL=["#4C78A8","#7B6BB0","#2FA19A","#5BA55B","#B8862F","#8C9A3C","#B05F8E","#C4636A","#D9822B","#A8634A","#3E96C8","#6B7A8F"];
const cor=d=>COL[DISC.indexOf(d)]||"#888";
let S={logs:[],goals:{d:6,w:36,m:156,disc:Object.fromEntries(DISC.map((d,i)=>[d,DG[i]]))}};
try{const x=localStorage.getItem("enem27");if(x)S=JSON.parse(x)}catch(e){}
const save=()=>{try{localStorage.setItem("enem27",JSON.stringify(S))}catch(e){}};
S.rev=S.rev||{};S.plan=S.plan||[];S.logs.forEach((l,i)=>{if(!l.id)l.id="l"+Date.now()+"_"+i});
const $=id=>document.getElementById(id);
const key=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
const parse=k=>{const[a,b,c]=k.split("-").map(Number);return new Date(a,b-1,c)};
const addD=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x};
const wk=d=>addD(d,-((d.getDay()+6)%7));
const mins=t=>{const[h,m]=t.split(":").map(Number);return h*60+m};
const hrs=l=>Math.max(0,((mins(l.f)-mins(l.i))%1440+1440)%1440-(+l.p||0))/60;
const fmt=h=>h.toFixed(1).replace(".",",")+" h";
const hm=h=>Math.floor(h)+":"+String(Math.round((h%1)*60)).padStart(2,"0");
const sum=(f)=>S.logs.filter(f).reduce((a,l)=>a+hrs(l),0);
const between=(a,b)=>l=>l.d>=key(a)&&l.d<=key(b);
const today=new Date(),T=key(today);

function streak(){
 const by={};S.logs.forEach(l=>by[l.d]=(by[l.d]||0)+hrs(l));
 let d=new Date(today),n=0;
 if(!by[key(d)])d=addD(d,-1);
 for(let i=0;i<800;i++){const h=by[key(d)]||0;
  if(h>0)n++;else if(d.getDay()!==0)break;
  d=addD(d,-1)}
 return n}
function card(l,v,s,p){return `<div class="card"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s||""}</div>${p!=null?`<div class="bar ${p>=1?"ok":""}"><i style="width:${Math.min(p,1)*100}%"></i></div>`:""}</div>`}
function rowsBars(el,data,max){$(el).innerHTML=data.map(([n,v])=>`<div class="hrow"><span><i class="dot" style="background:${cor(n)}"></i>${n}</span><div class="t"><i style="width:${max?v/max*100:0}%;background:${cor(n)}"></i></div><b>${fmt(v)}</b></div>`).join("")}
function cols(el,data,goal){
 const max=Math.max(...data.map(x=>x[1]),goal||0,1);
 $(el).innerHTML=data.map(([n,v])=>`<div title="${n}: ${fmt(v)}"><i style="height:${v/max*78}%"></i><span>${n}</span></div>`).join("")+(goal?`<div class="goal" style="bottom:calc(${goal/max*78}% + 22px)">${goal} h</div>`:"")}

function painel(){
 const ws=wk(today),ms=new Date(today.getFullYear(),today.getMonth(),1),ys=new Date(today.getFullYear(),0,1);
 const hw=sum(between(ws,addD(ws,6))),hmo=sum(between(ms,addD(new Date(today.getFullYear(),today.getMonth()+1,1),-1))),hy=sum(between(ys,new Date(today.getFullYear(),11,31))),ht=sum(()=>true);
 const dias=new Set(S.logs.filter(l=>hrs(l)>0).map(l=>l.d)).size;
 const per=DISC.map(d=>[d,sum(l=>l.s===d)]);
 const mx=Math.max(...per.map(x=>x[1])),mn=Math.min(...per.map(x=>x[1]));
 const G=S.goals,none=ht===0;
 $("kpi1").innerHTML=card("Horas no mês",fmt(hmo),"Meta: "+G.m+" h")+card("Horas na semana",fmt(hw),"Meta: "+G.w+" h")+card("Total no ano",fmt(hy),"Ano de "+today.getFullYear())+card("Total desde o início",fmt(ht),dias+" dias com registro")+card("Média por dia estudado",fmt(dias?ht/dias:0),"");
 $("kpi2").innerHTML=card("Dias consecutivos",streak()+" dias","Domingo de descanso não interrompe")+card("Maior carga",none?"—":per.find(x=>x[1]===mx)[0],none?"":fmt(mx))+card("Menor carga",none?"—":per.find(x=>x[1]===mn)[0],none?"":fmt(mn))+card("Progresso da semana",Math.round(hw/G.w*100)+"%","",hw/G.w)+card("Progresso do mês",Math.round(hmo/G.m*100)+"%","",hmo/G.m)+card("Revisões para hoje",revDue().length,"Atrasadas e do dia, na aba Revisões");
 const ph=S.plan.filter(x=>x.d===T),hr=today.getHours();
 $("hero").innerHTML=`<div class="ring" style="--p:${Math.min(hw/G.w,1)*100}%"><b>${Math.round(hw/G.w*100)}%</b></div><div><div style="font-size:20px;font-weight:700">${hr<12?"Bom dia":hr<18?"Boa tarde":"Boa noite"}</div><div class="sub" style="font-size:13px">Hoje: ${fmt(sum(l=>l.d===T))} estudadas · ${ph.filter(x=>x.done).length} de ${ph.length} tarefas · ${revDue().length} revisões pendentes</div><div class="sub">O anel mostra o progresso da meta semanal.</div></div>`;
 rowsBars("chDisc",per,mx);
 const gr=i=>COL[i];
 let acc=0,seg=[];per.forEach(([n,v],i)=>{const p=ht?v/ht*100:0;seg.push(`${gr(i)} ${acc}% ${acc+p}%`);acc+=p});
 $("donut").style.background=ht?`conic-gradient(${seg.join(",")})`:"var(--line)";
 $("leg").innerHTML=per.map(([n,v],i)=>`<div><i style="background:${gr(i)}"></i>${n} ${ht?Math.round(v/ht*100):0}%</div>`).join("");
 const w=[];for(let i=11;i>=0;i--){const a=addD(ws,-7*i);w.push([String(a.getDate()).padStart(2,"0")+"/"+String(a.getMonth()+1).padStart(2,"0"),sum(between(a,addD(a,6)))])}
 cols("chWeek",w,G.w);
 const m=[];for(let i=11;i>=0;i--){const a=new Date(today.getFullYear(),today.getMonth()-i,1),b=new Date(a.getFullYear(),a.getMonth()+1,0);m.push([MES[a.getMonth()],sum(between(a,b))])}
 cols("chMonth",m,G.m);
 const dd=[];for(let i=0;i<7;i++){const a=addD(ws,i);dd.push([DIAS[a.getDay()],sum(l=>l.d===key(a))])}
 cols("chDays",dd,G.d)}

function registro(){
 const f=$("flt").value,a=$("f1").value,b=$("f2").value;
 const L=S.logs.map((l,i)=>({...l,i})).filter(l=>(!f||l.s===f)&&(!a||l.d>=a)&&(!b||l.d<=b)).sort((x,y)=>y.d.localeCompare(x.d)||y.i-x.i);
 $("rows").innerHTML=L.map(l=>`<tr><td>${parse(l.d).toLocaleDateString("pt-BR")}</td><td>${DIAS[parse(l.d).getDay()]}</td><td><i class="dot" style="background:${cor(l.s)}"></i>${l.s}</td><td>${l.c||""}</td><td>${l.i}–${l.f}${l.p>0?` (−${l.p} min)`:""}</td><td><b>${hm(hrs(l))}</b></td><td>${l.t}</td><td><button data-del="${l.i}" title="Excluir">✕</button></td></tr>`).join("")||`<tr><td colspan="8" class="sub">Nenhuma sessão ainda.</td></tr>`;
 $("cnt").textContent=L.length+" sessões · "+fmt(L.reduce((x,l)=>x+hrs(l),0))+" no filtro"}

function metas(){
 const G=S.goals;
 $("gg").innerHTML=[["Diária","d"],["Semanal","w"],["Mensal","m"]].map(([n,k])=>`<label>${n}<input type="number" step="0.5" min="0" data-g="${k}" value="${G[k]}"></label>`).join("");
 $("gd").innerHTML=DISC.map(d=>`<label><span><i class="dot" style="background:${cor(d)}"></i>${d}</span><input type="number" step="0.5" min="0" data-gd="${d}" value="${G.disc[d]}"></label>`).join("");
 prog();return;
 const tot=DISC.reduce((a,d)=>a+(+G.disc[d]||0),0);
 $("gsum").textContent=Math.abs(tot-G.w)<.01?"As metas por disciplina somam a meta semanal.":"Atenção: as metas por disciplina somam "+fmt(tot)+" e a meta semanal é "+fmt(G.w)+".";
 const ws=wk(today);
 $("gprog").innerHTML=DISC.map(d=>{const h=sum(l=>l.s===d&&l.d>=key(ws)&&l.d<=key(addD(ws,6))),g=+G.disc[d]||0,p=g?h/g:0;
  return `<div class="hrow" style="grid-template-columns:96px 1fr 120px"><span>${d}</span><div class="t"><i style="width:${Math.min(p,1)*100}%;${p>=1?"background:var(--ok)":""}"></i></div><b>${fmt(h)} / ${g} h <span class="pill ${p>=1?"ok":"no"}">${Math.round(p*100)}%</span></b></div>`}).join("")}

function prog(){
 const G=S.goals,tot=DISC.reduce((a,d)=>a+(+G.disc[d]||0),0),ws=wk(today);
 $("gsum").textContent=Math.abs(tot-G.w)<.01?"As metas por disciplina somam a meta semanal.":"Atenção: as metas por disciplina somam "+fmt(tot)+" e a meta semanal é "+fmt(G.w)+".";
 $("gprog").innerHTML=DISC.map(d=>{const h=sum(l=>l.s===d&&l.d>=key(ws)&&l.d<=key(addD(ws,6))),g=+G.disc[d]||0,p=g?h/g:0;
  return `<div class="hrow" style="grid-template-columns:110px 1fr 150px"><span><i class="dot" style="background:${cor(d)}"></i>${d}</span><div class="t"><i style="width:${Math.min(p,1)*100}%;background:${cor(d)}"></i></div><b>${fmt(h)} / ${g} h <span class="pill ${p>=1?"ok":"no"}">${Math.round(p*100)}%</span></b></div>`}).join("")}

const REV=[1,7,30];
function revs(){const o=[];S.logs.filter(l=>l.r).forEach(l=>REV.forEach(n=>{const k=l.id+"_"+n;o.push({l,n,k,due:key(addD(parse(l.d),n)),done:!!S.rev[k]})}));return o}
function revDue(){return revs().filter(r=>!r.done&&r.due<=T)}
function revisao(){
 const R=revs(),lim=key(addD(today,14)),by=(a,b)=>a.due.localeCompare(b.due);
 const late=R.filter(r=>!r.done&&r.due<T).sort(by),now=R.filter(r=>!r.done&&r.due===T),next=R.filter(r=>!r.done&&r.due>T&&r.due<=lim).sort(by),done=R.filter(r=>r.done).sort((a,b)=>b.due.localeCompare(a.due)).slice(0,8);
 const item=r=>{const diff=Math.round((parse(T)-parse(r.due))/864e5);
  const w=r.done?"concluída":diff>0?"atrasada "+diff+(diff>1?" dias":" dia"):diff===0?"hoje":"em "+(-diff)+(diff<-1?" dias":" dia")+" · "+parse(r.due).toLocaleDateString("pt-BR");
  return `<div class="rv ${r.done?"done":""} ${!r.done&&diff>0?"late":""}"><input type="checkbox" data-rv="${r.k}" ${r.done?"checked":""}><i class="dot" style="background:${cor(r.l.s)};margin:0"></i><b>${r.l.s}</b><span>${r.l.c||"sem descrição"}</span><span class="tag">D+${r.n}</span><span class="when">${w}</span></div>`};
 const g=(t,a)=>a.length?`<h2>${t} (${a.length})</h2>`+a.map(item).join(""):"";
 $("rvl").innerHTML=R.length?(g("Atrasadas",late)+g("Para hoje",now)+g("Próximos 14 dias",next)+g("Concluídas recentes",done)||`<div class="sub" style="margin-top:14px">Nenhuma revisão pendente nos próximos 14 dias.</div>`):`<div class="sub" style="margin-top:14px">Nenhuma revisão agendada. Registre uma sessão com a opção de revisões marcada.</div>`;
 const n=late.length+now.length;$("bd").innerHTML=n?`<span class="badge">${n}</span>`:""}

const dur=x=>x.i&&x.f?(((mins(x.f)-mins(x.i))%1440+1440)%1440)/60:0;
const PR={a:["Alta","var(--bad)"],m:["Média","#b8862f"],b:["Baixa","var(--mut)"]};
let pv="semana",pa=new Date(today),dragId=null;
const pday=k=>S.plan.filter(x=>x.d===k);
function ptask(x,mini){
 return `<div class="pt ${x.done?"done":""} ${!x.done&&x.d<T?"od":""}" draggable="true" data-id="${x.id}" style="--c:${cor(x.s)}">${mini?"":`<input type="checkbox" data-pdone="${x.id}" ${x.done?"checked":""}>`}<div class="pi"><b>${x.s}</b>${mini?"":`<span>${x.c||""}</span><small>${x.i&&x.f?x.i+"–"+x.f:""}</small>`}</div>${mini?"":`<span class="pp" data-ppr="${x.id}" style="color:${PR[x.p][1]}">${PR[x.p][0]}</span><button data-pmv="${x.id}" title="Reagendar">↷</button><button data-pdel="${x.id}" title="Excluir">✕</button>`}</div>`}
function pcol(k){const d=parse(k),L=pday(k),h=L.reduce((s,x)=>s+dur(x),0);
 return `<div class="pc ${k===T?"hoje":""}" data-day="${k}"><div class="ph"><b>${DIAS[d.getDay()]} ${d.getDate()}</b><small>${h?fmt(h):""}</small></div>${L.map(x=>ptask(x)).join("")||`<div class="sub pe">Solte tarefas aqui</div>`}</div>`}
function plano(){
 const a=new Date(pa);let ks=[],h="",lab="";
 if(pv==="dia"){ks=[key(a)];lab=a.toLocaleDateString("pt-BR",{weekday:"long",day:"numeric",month:"long"});h=pcol(ks[0])}
 else if(pv==="semana"){const s=wk(a);ks=[0,1,2,3,4,5,6].map(i=>key(addD(s,i)));lab="Semana de "+s.toLocaleDateString("pt-BR",{day:"numeric",month:"long"});h=`<div class="wk">${ks.map(pcol).join("")}</div>`}
 else{const s=wk(new Date(a.getFullYear(),a.getMonth(),1));ks=Array.from({length:42},(_,i)=>key(addD(s,i)));lab=a.toLocaleDateString("pt-BR",{month:"long",year:"numeric"});
  h=`<div class="mg">${DIAS.slice(1).concat("Dom").map(d=>`<div class="dh">${d}</div>`).join("")}${ks.map(k=>{const d=parse(k),L=pday(k);return `<div class="mc ${d.getMonth()!==a.getMonth()?"out":""} ${k===T?"hoje":""}" data-day="${k}"><b data-go="${k}">${d.getDate()}</b>${L.slice(0,3).map(x=>ptask(x,1)).join("")}${L.length>3?`<small>+${L.length-3}</small>`:""}</div>`}).join("")}</div>`;
  ks=ks.filter(k=>parse(k).getMonth()===a.getMonth())}
 const L=S.plan.filter(x=>ks.includes(x.d)),dn=L.filter(x=>x.done).length,p=L.length?dn/L.length:0,od=S.plan.filter(x=>!x.done&&x.d<T);
 $("plab").textContent=lab;
 document.querySelectorAll("[data-pv]").forEach(b=>b.classList.toggle("on",b.dataset.pv===pv));
 $("pod").innerHTML=od.length?`<div class="od-b"><span>${od.length} ${od.length>1?"tarefas não concluídas":"tarefa não concluída"}</span><button class="btn" data-prs="1">Reagendar para hoje</button></div>`:"";
 $("ppg").innerHTML=`<div class="sub" style="margin-bottom:4px">${dn} de ${L.length} tarefas concluídas neste período</div><div class="bar ${p===1&&L.length?"ok":""}"><i style="width:${p*100}%"></i></div>`;
 $("pbody").innerHTML=h}
$("pfs").innerHTML=DISC.map(d=>`<option>${d}</option>`).join("");$("pfd").value=T;
$("pf").onsubmit=e=>{e.preventDefault();S.plan.push({id:"p"+Date.now(),d:$("pfd").value,s:$("pfs").value,c:$("pfc").value,i:$("pfi").value,f:$("pff").value,p:$("pfp").value,done:false});save();$("pfc").value="";pa=parse($("pfd").value);plano();painel()};
$("plano").onclick=e=>{const t=e.target,g=a=>t.closest("["+a+"]"),f=id=>S.plan.find(x=>x.id===id);let b;
 if(b=g("data-pv"))pv=b.dataset.pv;
 else if(b=g("data-pn")){const n=+b.dataset.pn;if(!n)pa=new Date(today);else if(pv==="mes")pa=new Date(pa.getFullYear(),pa.getMonth()+n,1);else pa=addD(pa,n*(pv==="dia"?1:7))}
 else if(b=g("data-go")){pa=parse(b.dataset.go);pv="dia"}
 else if(b=g("data-pmv")){const x=f(b.dataset.pmv);x.d=x.d<T?T:key(addD(parse(x.d),1))}
 else if(b=g("data-pdel"))S.plan=S.plan.filter(x=>x.id!==b.dataset.pdel);
 else if(b=g("data-ppr")){const x=f(b.dataset.ppr);x.p={a:"m",m:"b",b:"a"}[x.p]}
 else if(b=g("data-prs"))S.plan.forEach(x=>{if(!x.done&&x.d<T)x.d=T});
 else if(b=g("data-pdone")){f(b.dataset.pdone).done=b.checked}
 else return;
 save();plano();painel()};
$("pbody").ondragstart=e=>{const t=e.target.closest(".pt");if(t){dragId=t.dataset.id;e.dataTransfer.effectAllowed="move";e.dataTransfer.setData("text/plain",dragId)}};
$("pbody").ondragend=()=>dragId=null;
$("pbody").ondragover=e=>{if(dragId)e.preventDefault()};
$("pbody").ondrop=e=>{e.preventDefault();if(!dragId)return;const t=e.target.closest(".pt"),z=e.target.closest("[data-day]"),i=S.plan.findIndex(x=>x.id===dragId);if(i<0)return;const[it]=S.plan.splice(i,1);
 if(t&&t.dataset.id!==dragId){const j=S.plan.findIndex(x=>x.id===t.dataset.id);it.d=S.plan[j].d;S.plan.splice(j,0,it)}else if(z&&!t){it.d=z.dataset.day;S.plan.push(it)}else S.plan.splice(i,0,it);
 dragId=null;save();plano();painel()};

function all(){painel();registro();metas();revisao();plano()}
$("revisao").onchange=e=>{const k=e.target.dataset.rv;if(!k)return;if(e.target.checked)S.rev[k]=1;else delete S.rev[k];save();all()};
$("nav").onclick=e=>{const bt=e.target.closest("button[data-t]");if(!bt)return;const t=bt.dataset.t;
 document.querySelectorAll("nav button[data-t]").forEach(b=>b.classList.toggle("on",b===bt));
 ["painel","registro","plano","revisao","metas"].forEach(s=>$(s).classList.toggle("hide",s!==t))};
$("theme").onclick=()=>{const r=document.documentElement,dark=getComputedStyle(r).getPropertyValue("--bg").trim()==="#1b1b1b";r.dataset.theme=dark?"light":"dark"};
$("fs").innerHTML=DISC.map(d=>`<option>${d}</option>`).join("");
$("flt").innerHTML=`<option value="">Todas</option>`+DISC.map(d=>`<option>${d}</option>`).join("");
$("fd").value=T;
$("f").onsubmit=e=>{e.preventDefault();
 S.logs.push({d:$("fd").value,s:$("fs").value,c:$("fc").value,i:$("fi").value,f:$("ff").value,p:+$("fp").value||0,t:$("ft").value,o:$("fo").value,id:"l"+Date.now(),r:$("fr").checked&&$("ft").value!=="Revisão"});
 save();$("fc").value="";$("fo").value="";all()};
$("rows").onclick=e=>{const i=e.target.dataset.del;if(i==null)return;S.logs.splice(+i,1);save();all()};
["flt","f1","f2"].forEach(id=>$(id).onchange=registro);
$("metas").oninput=e=>{const t=e.target;
 if(t.dataset.g)S.goals[t.dataset.g]=+t.value||0;
 if(t.dataset.gd)S.goals.disc[t.dataset.gd]=+t.value||0;
 save();painel();prog();return;
 const G=S.goals,tot=DISC.reduce((a,d)=>a+(+G.disc[d]||0),0);
 $("gsum").textContent=Math.abs(tot-G.w)<.01?"As metas por disciplina somam a meta semanal.":"Atenção: as metas por disciplina somam "+fmt(tot)+" e a meta semanal é "+fmt(G.w)+".";
 const ws=wk(today);
 $("gprog").innerHTML=DISC.map(d=>{const h=sum(l=>l.s===d&&l.d>=key(ws)&&l.d<=key(addD(ws,6))),g=+G.disc[d]||0,p=g?h/g:0;
  return `<div class="hrow" style="grid-template-columns:96px 1fr 120px"><span>${d}</span><div class="t"><i style="width:${Math.min(p,1)*100}%;${p>=1?"background:var(--ok)":""}"></i></div><b>${fmt(h)} / ${g} h <span class="pill ${p>=1?"ok":"no"}">${Math.round(p*100)}%</span></b></div>`}).join("")};
all();
