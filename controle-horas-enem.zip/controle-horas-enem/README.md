# Controle de horas · ENEM 2027

Site para acompanhar horas de estudo, planejar a semana e o mês e fazer revisão espaçada (D+1, D+7 e D+30).

## O que tem no projeto

| Item | Detalhe |
|---|---|
| Tecnologias | HTML, CSS e JavaScript puro |
| TypeScript, componentes, imagens, fontes | Não há. O visual usa CSS e a fonte Arial do sistema. O ícone da aba é um SVG embutido no `index.html` |
| Dependências | Nenhuma. O `package.json` não lista pacotes |
| Dados | Ficam no `localStorage` do navegador, com a chave `enem27` |

## Estrutura

```
controle-horas-enem/
├─ index.html          página e estrutura das abas
├─ css/style.css       estilos (claro e escuro)
├─ js/app.js           toda a lógica: painel, registro, planejamento, revisões e metas
├─ server.js           servidor local sem dependências (opcional)
├─ package.json        script "npm start"
├─ docs/Controle_de_Horas_ENEM_2027.xlsx   planilha equivalente para Google Sheets
├─ .gitignore
└─ README.md
```

## Executar no Windows

**Opção 1, sem instalar nada:** extraia o ZIP e dê dois cliques em `index.html`.

**Opção 2, com servidor local:**

1. Instale o Node.js (versão 16 ou mais nova) em https://nodejs.org e confirme no PowerShell:
   ```powershell
   node -v
   ```
2. Extraia o ZIP, abra o PowerShell na pasta do projeto e rode:
   ```powershell
   npm start
   ```
3. Acesse http://localhost:3000 no navegador.

Para usar outra porta no PowerShell: `$env:PORT=8080; npm start`

Os dados ficam salvos por endereço. Quem abre pelo arquivo (`file://`) e quem abre por `localhost` enxergam registros separados.

## Enviar para o GitHub

1. Instale o Git para Windows em https://git-scm.com e crie um repositório vazio em https://github.com/new (sem README).
2. No PowerShell, dentro da pasta do projeto:
   ```powershell
   git init
   git add .
   git commit -m "Primeira versão"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/controle-horas-enem.git
   git push -u origin main
   ```

### Publicar online (opcional)

No repositório, vá em Settings, Pages, escolha a branch `main` e a pasta `/ (root)`. O site fica em `https://SEU-USUARIO.github.io/controle-horas-enem/`.

## Backup dos dados

Os registros moram só no navegador. Para copiar para outro computador, abra o console (F12) e rode `copy(localStorage.getItem("enem27"))`, guarde o texto e, no outro navegador, rode `localStorage.setItem("enem27", `COLE_AQUI`)` e recarregue.
